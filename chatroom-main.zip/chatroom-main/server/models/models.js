const MODEL_USER = 'users';
const MODEL_OTPS = 'otps';
const MODEL_MESSAGES = 'messages';
const MODEL_CHAT = 'chats';
const MODEL_MESSAGE_QUEUE = 'message_queue'


module.exports = {
  MODEL_USER,
  MODEL_OTPS,
  MODEL_MESSAGES,
  MODEL_CHAT,
  MODEL_MESSAGE_QUEUE
};
